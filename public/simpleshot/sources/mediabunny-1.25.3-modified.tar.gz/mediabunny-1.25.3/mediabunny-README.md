# MediaBunny conversion callback patch

`mediabunny@1.25.3.patch` exposes the existing `VideoEncodingConfig.onEncodedPacket`
callback through `ConversionVideoOptions`, forwarding it to the conversion's video
encoder. SimpleFlow uses it to reconcile Apple's AVC color-range metadata with
the encoded SPS before muxing. Without this correction, observed iPhone output
has limited-range H.264 samples but a full-range MP4 container tag.

The patch includes upstream TypeScript source, declarations, ESM module output,
and unminified ESM/CommonJS bundles. The package's public import and require
entrypoints are covered; pre-minified standalone bundles are not used or patched.
No codec payload, SPS, pixels, or encoding settings are rewritten by the callback.

MediaBunny is MPL-2.0. Preserve its license and notices and provide the modified
covered source (including this patch) with the release's source offer. Release
notice/source distribution preparation remains required before publication.
